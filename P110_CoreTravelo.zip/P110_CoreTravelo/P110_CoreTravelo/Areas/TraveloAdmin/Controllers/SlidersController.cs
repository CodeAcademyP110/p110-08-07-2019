﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P110_CoreTravelo.DAL;
using P110_CoreTravelo.Models;

namespace P110_CoreTravelo.Areas.TraveloAdmin.Controllers
{
    [Area("TraveloAdmin")]
    public class SlidersController : Controller
    {
        private readonly TraveloDbContext _context;

        public SlidersController(TraveloDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View(_context.Sliders);
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            Slider slider = await _context.Sliders.FindAsync(id);

            if(slider == null) return NotFound();

            return View(slider);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Post post) //model binding
        {
            if (!ModelState.IsValid)
            {
                return Content("Error bas verdi");
            }

            return Content($"Gonderdiyin title: {post.Basliq}, content: {post.Content}");
        }
    }
}